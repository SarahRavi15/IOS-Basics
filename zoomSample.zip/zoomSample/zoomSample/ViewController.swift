//
//  ViewController.swift
//  zoomSample
//
//  Created by Saranya Ravi on 13/03/24.
//

import UIKit

class ViewController: UIViewController {
    
    @IBOutlet var buttonWidth: NSLayoutConstraint!
    @IBOutlet var buttonHeight: NSLayoutConstraint!
    @IBOutlet var circularBtn: UIButton!
    @IBOutlet var scanImg: UIImageView!
    var initialTransform : CGAffineTransform?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        buttonHeight.constant = buttonWidth.constant
        circularBtn.layer.cornerRadius = circularBtn.frame.size.height / 2
        let pinchGesture = UIPinchGestureRecognizer(target: self, action: #selector(handleZoom(_ :)))
        scanImg.autoresizingMask = [.flexibleWidth,.flexibleHeight]
        scanImg.isUserInteractionEnabled = true
        scanImg.addGestureRecognizer(pinchGesture)
        // Do any additional setup after loading the view.
    }
    @objc func handleZoom(_ gestureRecognizer : UIPinchGestureRecognizer) {
        switch gestureRecognizer.state {
        case .began:
            initialTransform = scanImg.transform
        case .changed:
            guard let initialTransform = initialTransform else { return }
            let scaledTransform = initialTransform.scaledBy(x: gestureRecognizer.scale, y: gestureRecognizer.scale)
            scanImg.transform = scaledTransform
        case .ended,.cancelled:
            scanImg.transform = CGAffineTransform.identity
            initialTransform = nil
        default:
            break
        }
        
    }
}

