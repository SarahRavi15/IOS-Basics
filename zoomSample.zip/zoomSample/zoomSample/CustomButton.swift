//
//  CustomButton.swift
//  zoomSample
//
//  Created by Saranya Ravi on 18/03/24.
//

import UIKit

public class CustomButton: UIButton {
    
    private let border = CAShapeLayer()
    private let defaultColor : UIColor = .systemPink
    
    var buttonText : String
    var borderColor : UIColor
    var textColor : UIColor
    var bgColor : UIColor
    var symbolColor : UIColor
    var borderWidth : CGFloat
    var cornerRadius : CGFloat
    var sfSymbol : String
    
    init(buttonText: String, borderColor: UIColor, textColor: UIColor, bgColor: UIColor, symbolColor: UIColor, borderWidth: CGFloat, cornerRadius: CGFloat, sfSymbol: String) {
        self.buttonText = buttonText
        self.borderColor = borderColor
        self.textColor = textColor
        self.bgColor = bgColor
        self.symbolColor = symbolColor
        self.borderWidth = borderWidth
        self.cornerRadius = cornerRadius
        self.sfSymbol = sfSymbol
        
        super.init(frame: .zero)
        translatesAutoresizingMaskIntoConstraints = false
        
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }

    private func styleButton() {
        
    }
    
    /*
    // Only override draw() if you perform custom drawing.
    // An empty implementation adversely affects performance during animation.
    override func draw(_ rect: CGRect) {
        // Drawing code
    }
    */

}
